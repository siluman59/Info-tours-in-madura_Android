package com.example.wisata_madura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Monumen_sampang extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monumen_sampang);
    }
}