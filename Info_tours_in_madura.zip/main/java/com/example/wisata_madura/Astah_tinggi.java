package com.example.wisata_madura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Astah_tinggi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_astah_tinggi);
    }
}