package com.example.wisata_madura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Karaton_sumenep extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_karaton_sumenep);
    }
}