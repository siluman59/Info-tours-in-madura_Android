package com.example.wisata_madura;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class WisataAlam extends AppCompatActivity {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wisata_alam);


        listView = (ListView) findViewById(R.id.list);
        String[] values = new String[]{"Gili Labak, Sumenep", "Bukit Jaddih, Bangkalan",
                "Bukit Tinggi Daramista, Sumenep", "Puncak Ratu, Pamekasan","Bukit Cinta, Pamekasan",
                " Air Terjun Toroan, Sampang","Kota Tua Kalianget, Sumenep"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, values);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), gili_labak.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), bukit_jiddih.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), bukit_tinggi.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), puncak_ratu.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 4) {
                    Intent myIntent = new Intent(view.getContext(), Bukit_cinta.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 5) {
                    Intent myIntent = new Intent(view.getContext(), air_terjun_toroan.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 6) {
                    Intent myIntent = new Intent(view.getContext(), kalianget.class);
                    startActivityForResult(myIntent, 0);
                }
            }
        });
    }
    public void onBackPressed() {
        Intent intent = new Intent(WisataAlam.this, MenuUtama.class);
        finish();
        startActivity(intent);
}
}