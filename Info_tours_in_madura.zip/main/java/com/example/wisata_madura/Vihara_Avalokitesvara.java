package com.example.wisata_madura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Vihara_Avalokitesvara extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vihara_avalokitesvara);
    }
}